import subprocess
import os
import sys
import time
import json

def run_command(command):
    """Runs a command and waits for it to finish."""
    print(f"[*] Executing: {' '.join(command)}")
    try:
        # We use subprocess.run which waits for the process to complete
        result = subprocess.run(command, check=True)
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"[-] Error executing command: {e}")
        return False
    except Exception as e:
        print(f"[-] Unexpected error: {e}")
        return False

def check_has_data(filename):
    if os.path.exists(filename) and os.path.getsize(filename) > 0:
        try:
            with open(filename, "r", encoding="utf-8") as f:
                data = json.load(f)
                return bool(data)
        except Exception:
            # If there's content but it's not valid JSON, we still consider it not empty
            return True
    return False

def main():
    saved_has_data = check_has_data("saved.json")
    guild_has_data = check_has_data("guild.json")
    
    # If both saved.json and guild.json have data, skip creation and just run app.py
    if saved_has_data and guild_has_data:
        print("[+] Both saved.json and guild.json contain data.")
        print("\n--- Running app.py directly ---")
        run_command([sys.executable, "app4.py"])
        return
        
    # If only saved.json has data but guild.json does not, we should probably still avoid overwriting
    if saved_has_data and not guild_has_data:
        print("[-] Error: saved.json already contains data but guild.json does not. Please clear saved.json to run creator.py.")
        return

    # 1. Run creator.py
    # This will create the account and save it to saved.json
    print("\n--- STEP 1: Running creator.py ---")
    if run_command([sys.executable, "creator.py"]):
        print("[+] creator.py completed successfully.")
        
        # 2. Wait for success (small delay to ensure file is written)
        print("\n--- STEP 2: Waiting for success ---")
        time.sleep(2)
        
        if os.path.exists("saved.json"):
            print("[+] saved.json detected. Proceeding to bio change.")
            
            # 3. Run app1.py
            # This will start the automatic bio update
            print("\n--- STEP 3: Running app1.py ---")
            run_command([sys.executable, "app1.py", "--auto-only"])
            
            # 4. Run guild.py
            print("\n--- STEP 4: Running guild.py ---")
            run_command([sys.executable, "guild.py"])
            
            # 5. Wait 1 second
            print("\n--- STEP 5: Waiting 1 second ---")
            time.sleep(1)
            
            # 6. Run app.py
            print("\n--- STEP 6: Running app.py ---")
            run_command([sys.executable, "app4.py"])
        else:
            print("[-] Error: saved.json not found. Account creation might have failed.")
    else:
        print("[-] creator.py failed. Aborting.")

if __name__ == "__main__":
    main()