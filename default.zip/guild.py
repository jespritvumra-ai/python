import os
import time
import json
import logging
import binascii
from datetime import datetime
import requests
import urllib3
import jwt
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

import reqClan_pb2
import data_pb2
import my_pb2
import output_pb2

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ====================
# Config
# ====================
api_endpoints = {
    "IND": "https://client.ind.freefiremobile.com",
    "AMERICAS": "https://client.us.freefiremobile.com", 
    "DEFAULT": "https://clientbp.ggpolarbear.com"
}

AES_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
AES_IV = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

MAX_RETRIES = 3
RETRY_DELAY = 2

# ====================
# JWT Generation
# ====================
def encrypt_message(plaintext, key_bytes, iv_bytes):
    cipher = AES.new(key_bytes, AES.MODE_CBC, iv_bytes)
    padded_message = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded_message)

def get_oauth_token(uid, password):
    oauth_url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    payload = {
        'uid': uid,
        'password': password,
        'response_type': "token",
        'client_type': "2",
        'client_secret': "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        'client_id': "100067"
    }
    headers = {
        'User-Agent': "GarenaMSDK/4.0.19P9(SM-M526B ;Android 13;pt;BR;)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip"
    }
    try:
        oauth_response = requests.post(oauth_url, data=payload, headers=headers, timeout=10)
        if oauth_response.status_code == 200:
            oauth_data = oauth_response.json()
            if 'access_token' in oauth_data and 'open_id' in oauth_data:
                return oauth_data, None
            else:
                return None, f"OAuth error: {oauth_data.get('error', 'Unknown error')}"
        else:
            return None, f"OAuth HTTP {oauth_response.status_code}: {oauth_response.text}"
    except requests.RequestException as e:
        return None, f"OAuth request failed: {str(e)}"

def get_token_with_retry(uid, password):
    for attempt in range(MAX_RETRIES):
        oauth_data, error = get_oauth_token(uid, password)
        if oauth_data:
            return oauth_data
        elif attempt < MAX_RETRIES - 1:
            time.sleep(RETRY_DELAY * (2 ** attempt))
    return None

def major_login(access_token, open_id, key_bytes, iv_bytes, platform_type=4):
    try:
        game_data = my_pb2.GameData()
        game_data.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        game_data.game_name = "free fire"
        game_data.game_version = 1
        game_data.version_code = "1.120.1"
        game_data.os_info = "Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)"
        game_data.device_type = "Handheld"
        game_data.network_provider = "Verizon Wireless"
        game_data.connection_type = "WIFI"
        game_data.screen_width = 1280
        game_data.screen_height = 960
        game_data.dpi = "240"
        game_data.cpu_info = "ARMv7 VFPv3 NEON VMH | 2400 | 4"
        game_data.total_ram = 5951
        game_data.gpu_name = "Adreno (TM) 640"
        game_data.gpu_version = "OpenGL ES 3.0"
        game_data.user_id = "Google|74b585a9-0268-4ad3-8f36-ef41d2e53610"
        game_data.ip_address = "172.190.111.97"
        game_data.language = "en"
        game_data.open_id = open_id
        game_data.access_token = access_token
        game_data.platform_type = platform_type
        game_data.field_99 = str(platform_type)
        game_data.field_100 = str(platform_type)

        serialized_data = game_data.SerializeToString()
        encrypted_data = encrypt_message(serialized_data, key_bytes, iv_bytes)
        hex_encrypted_data = binascii.hexlify(encrypted_data).decode('utf-8')

        url = "https://loginbp.ggpolarbear.com/MajorLogin"
        headers = {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/octet-stream",
            "Expect": "100-continue",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB52"
        }
        edata = bytes.fromhex(hex_encrypted_data)

        response = requests.post(url, data=edata, headers=headers, timeout=10)
        if response.status_code == 200:
            data_dict = None
            try:
                example_msg = output_pb2.Garena_420()
                example_msg.ParseFromString(response.content)
                data_dict = {field.name: getattr(example_msg, field.name)
                             for field in example_msg.DESCRIPTOR.fields
                             if field.name not in ["binary", "binary_data", "Garena420"]}
            except Exception:
                try:
                    data_dict = response.json()
                except ValueError:
                    return None, f"Failed to parse MajorLogin response: {response.text}"

            if data_dict and "token" in data_dict:
                token_value = data_dict["token"]
                try:
                    decoded_token = jwt.decode(token_value, options={"verify_signature": False})
                    exp_timestamp = decoded_token.get("exp")
                    if exp_timestamp:
                        exp_date = datetime.fromtimestamp(exp_timestamp).strftime("%Y-%m-%d %H:%M:%S")
                        decoded_token["exp_date"] = exp_date
                    return {
                        "token": token_value,
                        "decoded_token": decoded_token
                    }, None
                except Exception as e:
                    return None, f"JWT decode failed: {str(e)}"
            else:
                return None, f"MajorLogin response missing token: {data_dict}"
        else:
            return None, f"MajorLogin HTTP {response.status_code}: {response.text}"
    except requests.RequestException as e:
        return None, f"MajorLogin request failed: {str(e)}"

def major_login_with_retry(access_token, open_id, key_bytes, iv_bytes, platform_type=4):
    for attempt in range(MAX_RETRIES):
        try:
            result, error = major_login(access_token, open_id, key_bytes, iv_bytes, platform_type)
            if result:
                return result
            elif attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY * (2 ** attempt))
        except Exception:
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY * (2 ** attempt))
    return None

def generate_jwt_from_credentials(uid, password):
    oauth_data = get_token_with_retry(uid, password)
    if not oauth_data:
        return None
    access_token = oauth_data['access_token']
    open_id = oauth_data['open_id']
    key_bytes = AES_KEY[:16]
    iv_bytes = AES_IV[:16]
    login_result = major_login_with_retry(access_token, open_id, key_bytes, iv_bytes, 4)
    if login_result:
        return login_result['token']
    return None

def get_region_from_jwt(jwt_token: str) -> str:
    try:
        decoded = jwt.decode(jwt_token, options={"verify_signature": False})
        region = decoded.get('lock_region', 'IND')
        if region and isinstance(region, str):
            return region.upper()
        return 'IND'
    except Exception:
        return 'IND'

def get_region_type(region):
    region = region.upper()
    if region == "IND":
        return "IND"
    elif region in ["BR", "US", "NA", "SAC"]:
        return "AMERICAS"
    else:
        return "DEFAULT"

# ====================
# Clan Management Functions
# ====================
def create_clan_payload(clan_id):
    try:
        message = reqClan_pb2.MyMessage()
        message.field_1 = int(clan_id)
        serialized_data = message.SerializeToString()
        cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
        encrypted_data = cipher.encrypt(pad(serialized_data, AES.block_size))
        return encrypted_data, None
    except Exception as e:
        return None, f"Payload creation failed: {str(e)}"

def parse_raw_response(response_content):
    try:
        resp_info = data_pb2.response()
        resp_info.ParseFromString(response_content)
        result = {}
        fields = [
            'id', 'special_code', 'timestamp1', 'value_a', 'status_code', 
            'sub_type', 'version', 'level', 'flags', 'welcome_message',
            'region', 'json_metadata', 'big_numbers', 'balance', 'score',
            'upgrades', 'achievements', 'total_playtime', 'energy', 'rank',
            'xp', 'timestamp2', 'error_code', 'last_active'
        ]
        for field in fields:
            if hasattr(resp_info, field):
                value = getattr(resp_info, field)
                if value is not None and value != 0 and value != "":
                    result[field] = value
        
        if hasattr(resp_info, 'guild_details') and resp_info.guild_details:
            guild_fields = ['region', 'clan_id', 'members_online', 'total_members', 'regional', 'reward_time', 'expire_time']
            guild_info = {}
            for field in guild_fields:
                if hasattr(resp_info.guild_details, field):
                    value = getattr(resp_info.guild_details, field)
                    if value is not None and value != 0 and value != "":
                        guild_info[field] = value
            if guild_info:
                result['guild_details'] = guild_info
        
        return result, None
    except Exception:
        try:
            decoded_text = response_content.decode('utf-8', errors='ignore').strip()
            if decoded_text:
                return {'error_text': decoded_text}, None
        except:
            pass
        return {
            'raw_hex': response_content.hex(),
            'raw_length': len(response_content),
            'raw_preview': str(response_content[:100]) if response_content else 'Empty'
        }, None

def make_clan_request(jwt_token, clan_id, endpoint):
    try:
        region = get_region_from_jwt(jwt_token)
        region_type = get_region_type(region)
        base_url = api_endpoints.get(region_type, api_endpoints["DEFAULT"])
        
        encrypted_data, payload_error = create_clan_payload(clan_id)
        if payload_error:
            return None, payload_error, None
        
        url = f"{base_url}/{endpoint}"
        headers = {
            "Expect": "100-continue",
            "Authorization": f"Bearer {jwt_token}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB52",
            "Content-Type": "application/octet-stream",
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 11; SM-A305F Build/RP1A.200720.012)",
            "Host": base_url.replace("https://", ""),
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip"
        }

        response = requests.post(url, headers=headers, data=encrypted_data, timeout=30)
        parsed_response, _ = parse_raw_response(response.content)
        
        if response.status_code == 200:
            if parsed_response:
                if 'error_code' in parsed_response and parsed_response['error_code'] != 0:
                    return response, f"Server returned error code: {parsed_response['error_code']}", parsed_response
                if 'error_text' in parsed_response:
                    return response, f"Server returned: {parsed_response['error_text']}", parsed_response
            return response, None, parsed_response
        else:
            error_msg = f"HTTP {response.status_code}"
            if parsed_response and 'error_text' in parsed_response:
                error_msg += f" | {parsed_response['error_text']}"
            return response, error_msg, parsed_response
            
    except Exception as e:
        return None, f"Error: {str(e)}", None

def join_guild_request(guild_id, jwt_token):
    return make_clan_request(jwt_token, guild_id, "RequestJoinClan")

# ====================
# Main Execution Flow
# ====================
def main():
    logger.info("Starting automation process...")

    # Load Accounts from saved.json
    try:
        with open("saved.json", "r") as f:
            accounts = json.load(f)
            if not isinstance(accounts, dict):
                logger.error("saved.json should contain a JSON object. Exiting.")
                return
    except Exception as e:
        logger.error(f"Failed to load saved.json: {e}")
        return

    # Load Guild IDs from guild.json
    try:
        with open("guild.json", "r") as f:
            guild_data = json.load(f)
            if isinstance(guild_data, list):
                guild_ids = guild_data
            elif isinstance(guild_data, dict):
                guild_ids = list(guild_data.values())
            else:
                guild_ids = [str(guild_data)]
    except Exception as e:
        logger.error(f"Failed to load guild.json: {e}")
        return

    if not guild_ids:
        logger.error("No guild IDs found in guild.json. Exiting.")
        return

    logger.info(f"Loaded {len(accounts)} accounts and {len(guild_ids)} guild IDs to join.")

    for uid, password in accounts.items():
        logger.info(f"Processing Account UID: {uid}")
        
        jwt_token = generate_jwt_from_credentials(uid, password)
        if not jwt_token:
            logger.error(f"Failed to login and generate JWT for UID: {uid}")
            continue
            
        region = get_region_from_jwt(jwt_token)
        logger.info(f"Logged in successfully. Region: {region}")

        for guild_id in guild_ids:
            logger.info(f"Attempting to join Guild ID: {guild_id}")
            response, error, parsed = join_guild_request(guild_id, jwt_token)
            
            if error:
                logger.error(f"Failed to join Guild {guild_id} with UID {uid}: {error}")
            else:
                logger.info(f"Successfully sent join request to Guild {guild_id} with UID {uid}! Status: {response.status_code}")
                if parsed:
                    logger.debug(f"Response: {parsed}")

    logger.info("Automation process completed successfully. Shutting down.")

if __name__ == "__main__":
    main()
